; ffspRyo  �R�}���h
; The CMD file.
;
; Two parts: 1. Command definition and  2. State entry
; (state entry is after the commands def section)
;
; 1. Command definition
; ---------------------
; Note: The commands are CASE-SENSITIVE, and so are the command names.
; The eight directions are:
;   B, DB, D, DF, F, UF, U, UB     (all CAPS)
;   corresponding to back, down-back, down, downforward, etc.
; The six buttons are:
;   a, b, c, x, y, z               (all lower case)
;   In default key config, abc are are the bottom, and xyz are on the
;   top row. For 2 button characters, we recommend you use a and b.
;   For 6 button characters, use abc for kicks and xyz for punches.
;
; Each [Command] section defines a command that you can use for
; state entry, as well as in the CNS file.
; The command section should look like:
;
;   [Command]
;   name = "some_name"
;   command = the_command
;   time = time (optional -- defaults to 15 if omitted)
;
; - some_name
;   A name to give that command. You'll use this name to refer to
;   that command in the state entry, as well as the CNS. It is case-
;   sensitive (QCB_a is NOT the same as Qcb_a or QCB_A).
;
; - command
;   list of buttons or directions, separated by commas.
;   Directions and buttons can be preceded by special characters:
;   slash (/) - means the key must be held down
;          egs. command = /D       ;hold the down direction
;               command = /F, a    ;hold fwd while you press a
;   tilde (~) - to detect key releases
;          egs. command = ~a       ;release the a button
;               command = ~D, F, a ;release down, press fwd, then a
;          If you want to detect "charge moves", you can specify
;          the time the key must be held down for (in game-ticks)
;          egs. command = ~30a     ;hold a for at least 30 ticks, then release
;               command = ~30
;   dollar ($) - Direction-only: detect as 4-way
;          egs. command = $D       ;will detect if D, DB or DF is held
;               command = $B       ;will detect if B, DB or UB is held
;   plus (+) - Buttons only: simultaneous press
;          egs. command = a+b      ;press a and b at the same time
;               command = x+y+z    ;press x, y and z at the same time
;   You can combine them:
;     eg. command = ~30$D, a+b     ;hold D, DB or DF for 30 ticks, release,
;                                  ;then press a and b together
;   It's recommended that for most "motion" commads, eg. quarter-circle-fwd,
;   you start off with a "release direction". This matches the way most
;   popular fighting games implement their engine.
;
; - time (optional)
;   Time allowed to do the command, given in game-ticks. Defaults to 15
;   if omitted
;
; If you have two or more commands with the same name, all of them will
; work. You can use it to allow multiple motions for the same move.
;
; Some common commands are given below. Delete, add, or modify as you wish.

;-|for AI sw |-------------------------------------------------------------------
[command]
name = "AI_1"
command = D, D, D, D, D, D, D, D
time = 1

[command]
name = "AI_2"
command = D, D, D, D, D, D, D, D
time = 1

[command]
name = "AI_3"
command = D, D, D, D, D, D, D, D
time = 1

[command]
name = "AI_4"
command = z, z, z, z, z, z, z, z
time = 1

[command]
name = "AI_5"
command = z, z, z, z, z, z, z, z
time = 1

[command]
name = "AI_6"
command = z, z, z, z, z, z, z, z
time = 1

[command]
name = "AI_7"
command = B, B, B, B, B, B, B, B
time = 1

[command]
name = "AI_8"
command = B, B, B, B, B, B, B, B
time = 1

[command]
name = "AI_9"
command = B, B, B, B, B, B, B, B
time = 1

[command]
name = "AI_10"
command = x, x, x, x, x, x, x, x
time = 1

[command]
name = "AI_11"
command = x, x, x, x, x, x, x, x
time = 1

[command]
name = "AI_12"
command = x, x, x, x, x, x, x, x
time = 1

[command]
name = "AI_13"
command = U, U, U, U, U, U, U, U
time = 1

[command]
name = "AI_14"
command = U, U, U, U, U, U, U, U
time = 1

[command]
name = "AI_15"
command = U, U, U, U, U, U, U, U
time = 1

[command]
name = "AI_16"
command = a, a, a, a, a, a, a, a
time = 1

[command]
name = "AI_17"
command = a, a, a, a, a, a, a, a
time = 1

[command]
name = "AI_18"
command = a, a, a, a, a, a, a, a
time = 1

[command]
name = "AI_19"
command = F, F, F, F, F, F, F, F
time = 1

[command]
name = "AI_20"
command = F, F, F, F, F, F, F, F
time = 1

[command]
name = "AI_21"
command = F, F, F, F, F, F, F, F
time = 1

[command]
name = "AI_22"
command = b, b, b, b, b, b, b, b
time = 1

[command]
name = "AI_23"
command = b, b, b, b, b, b, b, b
time = 1

[command]
name = "AI_24"
command = b, b, b, b, b, b, b, b
time = 1

[command]
name = "AI_25"
command = y, y, y, y, y, y, y, y
time = 1

[command]
name = "AI_26"
command = y, y, y, y, y, y, y, y
time = 1

[command]
name = "AI_27"
command = y, y, y, y, y, y, y, y
time = 1

[command]
name = "AI_28"
command = s, s, s, s, s, s, s, s
time = 1

[command]
name = "AI_29"
command = s, s, s, s, s, s, s, s
time = 1

;[command]
;name = "AI_30"
;command = s, s, s, s, s, s, s, s
;time = 1

;-| Super Motions |--------------------------------------------------------
;-----------------
; ranbu ���՗����R�}���h
[Command]
name = "ranbu_p"
command = ~D, DF, F, z+x
time = 20

[Command]
name = "ranbu_k"
command = ~D, DF, F, c+a
time = 20

[Command]
name = "ranbu_pk"
command = ~D, DF, F, z+c
time = 20

;;-----------------
;; 4632147 �V���C�j���O�N���X�^���r�b�g�R�}���h
;[Command]
;name = "4632147_a"
;command = ~B, F, D, B,  a
;time = 60
;
;[Command]
;name = "4632147_b"
;command = ~B, F, D, B,  b
;time = 60
;
;[Command]
;name = "4632147_c"
;command = ~B, F, D, B,  c
;time = 60
;
;[Command]
;name = "4632147_x"
;command = ~B, F, D, B,  x
;time = 60
;
;[Command]
;name = "4632147_y"
;command = ~B, F, D, B,  y
;time = 60
;
;[Command]
;name = "4632147_z"
;command = ~B, F, D, B,  z
;time = 60

;-----------------
; 641236 �e���ęጝ�R�}���h
[Command]
name = "641236_a"
command = ~F, B, D, F,  a
time = 60

[Command]
name = "641236_b"
command = ~F, B, D, F,  b
time = 60

[Command]
name = "641236_c"
command = ~F, B, D, F,  c
time = 60

[Command]
name = "641236_x"
command = ~F, B, D, F,  x
time = 60

[Command]
name = "641236_y"
command = ~F, B, D, F,  y
time = 60

[Command]
name = "641236_z"
command = ~F, B, D, F,  z
time = 60


;-----------------
; 236236 �g���R�}���h�~�Q
[Command]
name = "236236_a"
command = ~D, DF, F, D, DF, F, a
time = 60

[Command]
name = "236236_b"
command = ~D, DF, F, D, DF, F, b
time = 60

[Command]
name = "236236_c"
command = ~D, DF, F, D, DF, F, c
time = 60

[Command]
name = "236236_x"
command = ~D, DF, F, D, DF, F, x
time = 60

[Command]
name = "236236_y"
command = ~D, DF, F, D, DF, F, y
time = 60

[Command]
name = "236236_z"
command = ~D, DF, F, D, DF, F, z
time = 60

;-| Special Motions |------------------------------------------------------
;-----------------
; 236 �g���R�}���h
[Command]
name = "236_a"
command = ~D, DF, F, a

[Command]
name = "236_b"
command = ~D, DF, F, b

[Command]
name = "236_c"
command = ~D, DF, F, c

[Command]
name = "236_x"
command = ~D, DF, F, x

[Command]
name = "236_y"
command = ~D, DF, F, y

[Command]
name = "236_z"
command = ~D, DF, F, z

;;-----------------
;; 214  �����R�}���h
;[Command]
;name = "214_a"
;command = ~D, DB, B, a
;
;[Command]
;name = "214_b"
;command = ~D, DB, B, b
;
;[Command]
;name = "214_c"
;command = ~D, DB, B, c
;
;[Command]
;name = "214_x"
;command = ~D, DB, B, x
;
;[Command]
;name = "214_y"
;command = ~D, DB, B, y
;
;[Command]
;name = "214_z"
;command = ~D, DB, B, z

;-----------------
; 623  �����R�}���h
[Command]
name = "623_a"
command = ~F, D, DF, a

[Command]
name = "623_b"
command = ~F, D, DF, b

[Command]
name = "623_c"
command = ~F, D, DF, c

[Command]
name = "623_x"
command = ~F, D, DF, x

[Command]
name = "623_y"
command = ~F, D, DF, y

[Command]
name = "623_z"
command = ~F, D, DF, z


;;-----------------
;; 41236  �t���C���R�}���h
;[Command]
;name = "41236_a"
;command = ~B, D, F, a
;time = 30
;
;[Command]
;name = "41236_b"
;command = ~B, D, F, b
;time = 30
;
;[Command]
;name = "41236_c"
;command = ~B, D, F, c
;time = 30
;
;[Command]
;name = "41236_x"
;command = ~B, D, F, x
;time = 30
;
;[Command]
;name = "41236_y"
;command = ~B, D, F, y
;time = 30
;
;[Command]
;name = "41236_z"
;command = ~B, D, F, z
;time = 30

;-----------------
; 16  �����r�R�}���h
[Command]
name = "16_a"
command = ~DB, F, a
time = 30

[Command]
name = "16_b"
command = ~DB, F, b
time = 30

[Command]
name = "16_c"
command = ~DB, F, c
time = 30

[Command]
name = "16_x"
command = ~DB, F, x
time = 30

[Command]
name = "16_y"
command = ~DB, F, y
time = 30

[Command]
name = "16_z"
command = ~DB, F, z
time = 30

;-----------------
; 646  �b�󌝃R�}���h
;[Command]
;name = "646_a"
;command = ~F, B, F, a
;time = 30

;[Command]
;name = "646_b"
;command = ~F, B, F, b
;time = 30

;[Command]
;name = "646_c"
;command = ~F, B, F, c
;time = 30

[Command]
name = "646_x"
command = ~F, B, F, x
time = 30

[Command]
name = "646_y"
command = ~F, B, F, y
time = 30

[Command]
name = "646_z"
command = ~F, B, F, z
time = 30


;;--------------------
;;Charge_Down_up
;[Command]
;name = "chargedownup_a"
;command = ~60$D, U, a
;time = 10
;
;[Command]
;name = "chargedownup_b"
;command = ~60$D, U, b
;time = 10
;
;[Command]
;name = "chargedownup_c"
;command = ~60$D, U, c
;time = 10
;
;[Command]
;name = "chargedownup_x"
;command = ~60$D, U, x
;time = 10
;
;[Command]
;name = "chargedownup_y"
;command = ~60$D, U, y
;time = 10
;
;[Command]
;name = "chargedownup_z"
;command = ~60$D, U, z
;time = 10
;
;;--------------------
;;Charge_Back_fwd
;[Command]
;name = "chargebackfwd_a"
;command = ~60$B, F, a
;time = 10
;
;[Command]
;name = "chargebackfwd_b"
;command = ~60$B, F, b
;time = 10
;
;[Command]
;name = "chargedownup_c"
;command = ~60$D, U, c
;time = 10
;
;[Command]
;name = "chargedownup_x"
;command = ~60$D, U, x
;time = 10
;
;[Command]
;name = "chargedownup_y"
;command = ~60$D, U, y
;time = 10
;
;[Command]
;name = "chargedownup_z"
;command = ~60$D, U, z
;time = 10



;-| Double Tap |-----------------------------------------------------------
[Command]
name = "FF";Required (do not remove)
command = F, F
time = 10

[Command]
name = "BB";Required (do not remove)
command = B, B
time = 10

;-| �����{�^���������� |---------------------------------------------------------
[Command]
name = "abc"
command = a+b+c
time = 1

[Command]
name = "ab"
command = a+b
time = 1

[Command]
name = "bc"
command = b+c
time = 1

[Command]
name = "xyz"
command = x+y+z
time = 1

[Command]
name = "xy"
command = x+y
time = 1

[Command]
name = "yz"
command = y+z
time = 1

[Command]
name = "ax"
command = a+x
time = 1

[Command]
name = "by"
command = b+y
time = 1

[Command]
name = "cz"
command = c+z
time = 1

;-| 2/3 Button Combination |-----------------------------------------------
[Command]
name = "recovery";Required (do not remove)
command = a+x
time = 1

;-| Dir + Button |---------------------------------------------------------
[Command]
name = "fwd_a"
command = /F,a
time = 1

[Command]
name = "fwd_b"
command = /F,b
time = 1

[Command]
name = "fwd_c"
command = /F,c
time = 1

[Command]
name = "fwd_x"
command = /F,x
time = 1

[Command]
name = "fwd_y"
command = /F,y
time = 1

[Command]
name = "fwd_z"
command = /F,z
time = 1

[Command]
name = "back_a"
command = /B,a
time = 1

[Command]
name = "back_b"
command = /B,b
time = 1

[Command]
name = "back_c"
command = /B,c
time = 1

[Command]
name = "back_x"
command = /B,x
time = 1

[Command]
name = "back_y"
command = /B,y
time = 1

[Command]
name = "back_z"
command = /B,z
time = 1

[Command]
name = "down_a"
command = /$D,a
time = 1

[Command]
name = "down_b"
command = /$D,b
time = 1

[Command]
name = "down_c"
command = /$D,c
time = 1

[Command]
name = "down_x"
command = /$D,x
time = 1

[Command]
name = "down_y"
command = /$D,y
time = 1

[Command]
name = "down_z"
command = /$D,z
time = 1

[Command]
name = "fwd_ab"
command = /F, a+b
time = 1

[Command]
name = "back_ab"
command = /B, a+b
time = 1

[Command]
name = "6_a"
command = /F, a
;time = 1

[Command]
name = "6_x"
command = /F, x
;time = 1

;-| �{�^���������ςȂ� |---------------------------------------------------------

[Command]
name = "hold_a"
command = /a
time = 1

[Command]
name = "hold_b"
command = /b
time = 1

[Command]
name = "hold_c"
command = /c
time = 1

[Command]
name = "hold_x"
command = /x
time = 1

[Command]
name = "hold_y"
command = /y
time = 1

[Command]
name = "hold_z"
command = /z
time = 1

[Command]
name = "hold2_a"
command = /a
time = 2

[Command]
name = "hold2_b"
command = /b
time = 2

[Command]
name = "hold2_c"
command = /c
time = 2

[Command]
name = "hold2_x"
command = /x
time = 2

[Command]
name = "hold2_y"
command = /y
time = 2

[Command]
name = "hold2_z"
command = /z
time = 2

;-| Single Button |---------------------------------------------------------
[Command]
name = "a"
command = a
time = 1

[Command]
name = "b"
command = b
time = 1

[Command]
name = "c"
command = c
time = 1

[Command]
name = "x"
command = x
time = 1

[Command]
name = "y"
command = y
time = 1

[Command]
name = "z"
command = z
time = 1

[Command]
name = "s"
command = s
time = 1

;-| Hold Dir |--------------------------------------------------------------
[Command]
name = "holdfwd";Required (do not remove)
command = /$F
time = 1

[Command]
name = "holdback";Required (do not remove)
command = /$B
time = 1

[Command]
name = "holdup";Required (do not remove)
command = /$U
time = 1

[Command]
name = "holddown";Required (do not remove)
command = /$D
time = 1

[Command]
name = "holdfwddown"
command = /$DF
time = 1


;---------------------------------------------------------------------------
; 2. State entry
; --------------
; This is where you define what commands bring you to what states.
;
; Each state entry block looks like:
;   [State -1]                  ;Don't change this
;   type = ChangeState          ;Don't change this
;   value = new_state_number
;   trigger1 = command = "command_name"
;   . . .  (any additional triggers)
;
; - new_state_number is the number of the state to change to
; - command_name is the name of the command (from the section above)
; - Useful triggers to know:
;   - statetype
;       S, C or A : current state-type of player (stand, crouch, air)
;   - ctrl
;       0 or 1 : 1 if player has control. Unless "interrupting" another
;                move, you'll want ctrl = 1
;   - stateno
;       number of state player is in - useful for "move interrupts"
;   - movecontact
;       0 or 1 : 1 if player's last attack touched the opponent
;                useful for "move interrupts"
;
; Note: The order of state entry is important.
;   State entry with a certain command must come before another state
;   entry with a command that is the subset of the first.  
;   For example, command "fwd_a" must be listed before "a", and
;   "fwd_ab" should come before both of the others.
;
; For reference on triggers, see CNS documentation.
;
; Just for your information (skip if you're not interested):
; This part is an extension of the CNS. "State -1" is a special state
; that is executed once every game-tick, regardless of what other state
; you are in. 


; Don't remove the following line. It's required by the CMD standard.
[Statedef -1]
;===========================================================================
; AI ��Փx�ݒ�
;-----------------
; Var(29) �ɃZ�b�g����l�ɂāAAI �ɂ��R���g���[���p�x�𐧌䂵�܂��B
; AI ����������Ɗ�������ꍇ�̓Z�b�g����l��������
; AI ���シ����Ɗ�������ꍇ�̓Z�b�g����l��傫���ύX���Ă��������B
; 
; [�Z�b�g�l�̖ڈ�]
; 999  �F�ŋ��B�ق�100���̊m����AI���䂪�����܂�
; 500  �F�����x�B ��50���̊m����AI���䂪�����܂�
; 0    �FOFF�B AI���䂪�����ƂȂ�܂�
;-----------------
[State -1,AI_Dif]
type=VarSet
trigger1   = RoundState   < 2       ; Not in Fight
v          = 29
value      = 128                    ; �� ���̒l��ύX����AI���x����ύX���܂�
;===========================================================================
;===========================================================================
;�����{�����[�� ����p
;===========================================================================
;init Var(1)
[State -1,Var_1]
type                = Varset
trigger1            = RoundState  < 2       ; Not in Fight
v                   = 1 
value               = 128                   


;===========================================================================
         AI Control
;===========================================================================
; �Γːi�ZAI �V�n�e����
[State -1,1]
type = ChangeState
value = 3200 ; ���G�Z�A�o�������Ƃ���ɗǂ�����
triggerall = Random       < Var(29)      ; ��Փx
triggerall = ctrl && (var(20)=20) ; ����\��AI����
triggerall = movetype != H ; �_���[�W���łȂ�
triggerall = statetype != A ; �󒆂łȂ�
trigger1   = power > 1000 || Life < 300 ; Power 1000 over or Life 300 under >
trigger1 = var(22) - p2bodydist X >= 6 ; 6�h�b�g�ȏ�ڋ�
trigger1 = p2movetype = A ; ���肪�U������
trigger1 = p2bodydist X = ( 30, 80 ) ; ����̋߂�

; �Γːi�ZAI �r���h�A�b�p�[
[State -1,1]
type = ChangeState
value = 1120 ; ���G�Z�A�o�������Ƃ���ɗǂ�����
triggerall = Random       < Var(29)      ; ��Փx
triggerall = ctrl && (var(20)=20) ; ����\��AI����
triggerall = movetype != H ; �_���[�W���łȂ�
triggerall = statetype != A ; �󒆂łȂ�
trigger1 = var(22) - p2bodydist X >= 6 ; 6�h�b�g�ȏ�ڋ�
trigger1 = p2movetype = A ; ���肪�U������
trigger1 = p2bodydist X = ( 0, 65 ) ; ����̋߂�

; �ߋ��ʒu�̋L�^
[State -1,1]
type = Varset
trigger1 = var(20) = 20 ; AI�̎�
var(22) = ceil(p2bodydist X)

---------------------------------------------------------------
; Charge Stop
[State -1,1]
type = ChangeState
value = 902
trigger1   = StateNo      = 901         ; Charging
trigger1   = var(20)      = 20          ; AI = on
;trigger1   = P2movetype   = A           ; in Attack
trigger1   = p2bodydist X < 120         ; P2>

---------------------------------------------------------------
; Combo Attack
; Airial Start
[State -1,1]
type = ChangeState
value = 40                              ; Jump
triggerall = Random       < Var(29)      ; ��Փx
trigger1   = P2movetype  != A           ; Not in Attack
trigger1   = var(20)      = 20          ; AI = on
trigger1   = StateNo      = 420         ; Attack by Crouch z
trigger1   = movehit                    ; Hit!
                                        
; Case by case ...  :-P
; Ryuko-Ranbu
[State -1,1]
type = ChangeState
value = 3100
triggerall = Random       < Var(29)      ; ��Փx
triggerall = PrevStateNo != 3108        ; �����Z���J��Ԃ��Ȃ�
triggerall = P2movetype  != A           ; Not in Attack
triggerall = var(20)      = 20          ; AI = on
triggerall = power > 2999 || Life < 200 ; Power Full or Life 200 under >
triggerall = p2bodydist X < 200         ; Near P2>
trigger1   = StateNo      = 3200        ; Attack by Tenchi-Haoh-Ken
trigger1   = movehit                    ; Hit!
trigger2   = StateNo      = 1212        ; Attack by Hiensippu-Kyaku(M)
trigger2   = AnimElem     = 3           ; Hit Def
trigger2   = movehit                    ; Hit!
trigger2   = AnimTime     = 0           ; Don't Cancel
trigger3   = p2life       < 450         ; P2 LIFE Harf
trigger3   = ctrl                       ; Enable Control
trigger3   = statetype    = S           ; Standing
trigger3   = p2statetype != L           ; Not Lie down
trigger4   = life         < 200         ; >
trigger4   = p2life       > 450         ; P2 LIFE Harf
trigger4   = ctrl                       ; Enable Control
trigger4   = statetype    = S           ; Standing
trigger4   = p2statetype != L           ; Not Lie down

; Zanretsu-Ken(L)
[State -1,1]
type = ChangeState
value = 1320
triggerall = Random       < Var(29)      ; ��Փx
triggerall = PrevStateNo != 1322        ; �����Z���J��Ԃ��Ȃ�
triggerall = P2movetype  != A           ; Not in Attack
triggerall = var(20)      = 20          ; AI = on
triggerall = statetype    = S           ; Standing
trigger1   = StateNo      = 1212        ; Attack by Hiensippu-Kyaku
trigger1   = movehit                    ; Hit!
trigger1   = AnimTime     = 0           ; Don't Cancel
trigger2   = StateNo      = 300         ; Attack by Strong Attack
trigger2   = movecontact                ; Hit!
trigger3   = p2bodydist X < 30          ; Near P2>
trigger3   = p2bodydist X > 20          ; Near P2>
trigger3   = p2statetype  = L           ; Lie down
trigger3   = ctrl                       ; Enable Control

; Haoh-Shohkoh-Ken(S)
[State -1,1]
type = ChangeState
value = 1400
triggerall = Random       < Var(29)      ; ��Փx
triggerall = PrevStateNo != 1400        ; �����Z���J��Ԃ��Ȃ�
triggerall = var(20)      = 20          ; AI = on
triggerall = statetype    = S           ; Standing
triggerall = ctrl                       ; Enable Control
triggerall = Random      <= 128
triggerall = P2movetype  != H           ; Not in Damege
trigger1   = p2bodydist X < 120         ; Far from P2>
trigger1   = p2bodydist X > 100         ; Far from P2>
trigger1   = p2statetype  = C           ; Crouch
trigger2   = p2bodydist X < 120         ; Far from P2>
trigger2   = p2bodydist X > 100         ; Far from P2>
trigger2   = p2statetype  = A           ; in Air
trigger3   = p2bodydist X < 160         ; Far from P2>
trigger3   = p2bodydist X > 100         ; Far from P2>
trigger3   = p2statetype  = L           ; Lie down

; Hien-Shippu-Kyaku(M)
[State -1,1]
type = ChangeState
value = 1210
triggerall = Random       < Var(29)      ; ��Փx
triggerall = var(20)      = 20          ; AI = on
triggerall = statetype    = S           ; Standing
triggerall = ctrl                       ; Enable Control
triggerall = Random      >= 129
triggerall = P2statetype != L           ; Not Lie Down
trigger1   = p2bodydist X < 120         ; Far from P2>
trigger1   = p2bodydist X > 100         ; Far from P2>
trigger1   = p2statetype  = C           ; Crouch
trigger2   = p2bodydist X < 120         ; Far from P2>
trigger2   = p2bodydist X > 100         ; Far from P2>
trigger2   = p2statetype  = A           ; in Air

; Haoh-Shohkoh-Ken(L)
[State -1,1]
type = ChangeState
value = 1420
triggerall = Random       < Var(29)      ; ��Փx
triggerall = PrevStateNo != 1420        ; �����Z���J��Ԃ��Ȃ�
triggerall = var(20)      = 20          ; AI = on
triggerall = statetype    = S           ; Standing
triggerall = ctrl                       ; Enable Control
triggerall = Random      <= 128
trigger1   = p2bodydist X > 160         ; Far from P2>
trigger1   = p2statetype  = L           ; Lie down
trigger2   = p2bodydist X > 120         ; Far from P2>
trigger2   = p2statetype  = C           ; Crouch
trigger3   = p2bodydist X > 120         ; Far from P2>
trigger3   = p2statetype  = A           ; in Air

; Ko-oh-Ken(L)
[State -1,1]
type = ChangeState
value = 1020
;triggerall = PrevStateNo != 1020        ; �����Z���J��Ԃ��Ȃ�
triggerall = Random       < Var(29)      ; ��Փx
triggerall = var(20)      = 20          ; AI = on
triggerall = statetype    = S           ; Standing
triggerall = ctrl                       ; Enable Control
;triggerall = Random      >= 129
trigger1   = p2bodydist X > 160         ; Far from P2>
trigger1   = p2statetype  = L           ; Lie down
trigger2   = p2bodydist X > 120         ; Far from P2>
trigger2   = p2statetype  = C           ; Crouch

---------------------------------------------------------------
; Inside Action
; Throw
[State -1,1]
type = ChangeState
value = 1500
triggerall = Random       < Var(29)      ; ��Փx
triggerall = PrevStateNo != [1500,1599] ; �����Z���J��Ԃ��Ȃ�
trigger1   = P2movetype  != A           ; Not in Attack
trigger1   = p2statetype != L           ; Not Lie down
trigger1   = p2statetype != A           ; Not in Air
trigger1   = var(20)      = 20          ; AI = on
trigger1   = p2bodydist X < 18          ; Near P2>
trigger1   = statetype    = S           ; Standing
trigger1   = ctrl                       ; Enable Control
                                        
; Tenchi-Haoh-Ken
[State -1,1]
type = ChangeState
value = 3200
triggerall = Random       < Var(29)      ; ��Փx
trigger1   = P2movetype   = A           ; in Attack
trigger1   = p2statetype != L           ; Not Lie down
trigger1   = var(20)      = 20          ; AI = on
trigger1   = p2bodydist X < 30          ; Near P2>
trigger1   = p2bodydist X > 20          ; Near P2>
trigger1   = statetype    = S           ; Standing
trigger1   = power > 1000 || Life < 300 ; Power 1000 over or Life 300 under >
trigger1   = ctrl                       ; Enable Control

; Build Upper
[State -1,1]
type = ChangeState
value = 1100
triggerall = Random       < Var(29)      ; ��Փx
trigger1   = PrevStateNo != 1104        ; �����Z���J��Ԃ��Ȃ�
trigger1   = P2movetype   = A           ; in Attack
trigger1   = p2statetype != L           ; Not Lie down
trigger1   = var(20)      = 20          ; AI = on
trigger1   = p2bodydist X < 40          ; Near P2>
trigger1   = statetype    = S           ; Standing
;trigger1   = power        < 1000        ; no Power>
;trigger1   = Life         > 300         ; enough Life>
trigger1   = ctrl                       ; Enable Control

---------------------------------------------------------------
;AI Sign SW
[State -1,2]
type = Varset
trigger1   = Facing       = -1      ; 2P Side
trigger1   = RoundState   < 2       ; Not in Fight
v = 21
value = 2

;AI Sign SW
[State -1,2]
type = Varset
trigger1   = Facing       = 1       ; 1P Side
trigger1   = RoundState   < 2       ; Not in Fight
v = 21
value = 1

;AI Sign
[State -1,3]
type = explod
triggerall = var(20) != 20
triggerall = var(21)  = 2
;triggerall = Facing   = -1    ; 2P Side
trigger1  = command = "AI_1"
trigger2  = command = "AI_2"
trigger3  = command = "AI_3"
trigger4  = command = "AI_4"
trigger5  = command = "AI_5"
trigger6  = command = "AI_6"
trigger7  = command = "AI_7"
trigger8  = command = "AI_8"
trigger9  = command = "AI_9"
trigger10 = command = "AI_10"
trigger11 = command = "AI_11"
trigger12 = command = "AI_12"
trigger13 = command = "AI_13"
trigger14 = command = "AI_14"
trigger15 = command = "AI_15"
trigger16 = command = "AI_16"
trigger17 = command = "AI_17"
trigger18 = command = "AI_18"
trigger19 = command = "AI_19"
trigger20 = command = "AI_20"
trigger21 = command = "AI_21"
trigger22 = command = "AI_22"
trigger23 = command = "AI_23"
trigger24 = command = "AI_24"
trigger25 = command = "AI_25"
trigger26 = command = "AI_26"
trigger27 = command = "AI_27"
trigger28 = command = "AI_28"
trigger29 = command = "AI_29"
;trigger30 = command = "AI_30"
;persistent = 0
id = 9999
anim = 9999;1408
pos = -2,22  ;-50,60
postype = right
sprpriority = 7
removetime = -1
facing=-1
supermove = 1
bindtime = -1
ontop = 1
;ownpal = 1

;AI Sign
[State -1,3]
type = explod
triggerall = var(20) != 20
triggerall = var(21)  = 1
;triggerall = Facing   =  1     ; 1P Side
trigger1  = command = "AI_1"
trigger2  = command = "AI_2"
trigger3  = command = "AI_3"
trigger4  = command = "AI_4"
trigger5  = command = "AI_5"
trigger6  = command = "AI_6"
trigger7  = command = "AI_7"
trigger8  = command = "AI_8"
trigger9  = command = "AI_9"
trigger10 = command = "AI_10"
trigger11 = command = "AI_11"
trigger12 = command = "AI_12"
trigger13 = command = "AI_13"
trigger14 = command = "AI_14"
trigger15 = command = "AI_15"
trigger16 = command = "AI_16"
trigger17 = command = "AI_17"
trigger18 = command = "AI_18"
trigger19 = command = "AI_19"
trigger20 = command = "AI_20"
trigger21 = command = "AI_21"
trigger22 = command = "AI_22"
trigger23 = command = "AI_23"
trigger24 = command = "AI_24"
trigger25 = command = "AI_25"
trigger26 = command = "AI_26"
trigger27 = command = "AI_27"
trigger28 = command = "AI_28"
trigger29 = command = "AI_29"
;trigger30 = command = "AI_30"
;persistent = 0
id = 9999
anim = 9999;1408
pos =   0,22 ;50,60
postype = left
sprpriority = 7
removetime = -1
supermove = 1
bindtime = -1
ontop = 1
;ownpal = 1

; AI swich -> ON
[State -1,2]
type = Varset
triggerall = var(20) != 20
trigger1 = command = "AI_1"
trigger2 = command = "AI_2"
trigger3 = command = "AI_3"
trigger4 = command = "AI_4"
trigger5 = command = "AI_5"
trigger6 = command = "AI_6"
trigger7 = command = "AI_7"
trigger8 = command = "AI_8"
trigger9 = command = "AI_9"
trigger10 = command = "AI_10"
trigger11 = command = "AI_11"
trigger12 = command = "AI_12"
trigger13 = command = "AI_13"
trigger14 = command = "AI_14"
trigger15 = command = "AI_15"
trigger16 = command = "AI_16"
trigger17 = command = "AI_17"
trigger18 = command = "AI_18"
trigger19 = command = "AI_19"
trigger20 = command = "AI_20"
trigger21 = command = "AI_21"
trigger22 = command = "AI_22"
trigger23 = command = "AI_23"
trigger24 = command = "AI_24"
trigger25 = command = "AI_25"
trigger26 = command = "AI_26"
trigger27 = command = "AI_27"
trigger28 = command = "AI_28"
trigger29 = command = "AI_29"
;trigger30 = command = "AI_30"
v = 20
value = 20

;===========================================================================
         ���K�E�Z
;===========================================================================


;===========================================================================
;init Var(6)
[State -1,Var_6]
type                = Varset
trigger1            = RoundState  < 2       ; Not in Fight
v                   = 6
value               = 0

;��s���͉����p
[State -1, 1]
type       = VarAdd
trigger1   = Var(2) < 18
v          = 2
value      = 1


;---------------------------------------------------------------------------
;�������i���j
[State -1, 1]
type       = Varset
trigger1   = Command = "236_x"
v          = 0
value      = 1000

;---------------------------------------------------------------------------
;�������i���j
[State -1, 1]
type       = Varset
trigger1   = Command = "236_y"
v          = 0
value      = 1010

;---------------------------------------------------------------------------
;�������i��j
[State -1, 1]
type       = Varset
trigger1   = Command = "236_z"
v          = 0
value      = 1020

;---------------------------------------------------------------------------
;�󒆌������i���j
[State -1, 1]
type       = Varset
trigger1   = Command = "236_a"
trigger1   = statetype = A
v          = 0
value      = 1000

;---------------------------------------------------------------------------
;�󒆌������i���j
[State -1, 1]
type       = Varset
trigger1   = Command = "236_b"
trigger1   = statetype = A
v          = 0
value      = 1010

;---------------------------------------------------------------------------
;�󒆌������i��j
[State -1, 1]
type       = Varset
trigger1   = Command = "236_c"
trigger1   = statetype = A
v          = 0
value      = 1020

;---------------------------------------------------------------------------
;�󒆌���������p
[State -1, 1]
type       = Varset
trigger1   = Command = "236_x"
trigger2   = Command = "236_y"
trigger3   = Command = "236_z"
v          = 6
value      = -100

[State -1, 1]
type       = Varset
trigger1   = Command = "236_a"
trigger2   = Command = "236_b"
trigger3   = Command = "236_c"
v          = 6
value      = 0

;---------------------------------------------------------------------------
;�r���h�A�b�p�[�i���j
[State -1, 1]
type       = Varset
trigger1   = Command = "623_x"
v          = 0
value      = 1100

;---------------------------------------------------------------------------
;�r���h�A�b�p�[�i���j
[State -1, 1]
type       = Varset
trigger1   = Command = "623_y"
v          = 0
value      = 1110

;---------------------------------------------------------------------------
;�r���h�A�b�p�[�i��j
[State -1, 1]
type       = Varset
trigger1   = Command = "623_z"
v          = 0
value      = 1120

;---------------------------------------------------------------------------
; �򉍎����r�i���j
[State -1, 1]
type       = Varset
trigger1   = Command = "16_a"
v          = 0
value      = 1200

;---------------------------------------------------------------------------
; �򉍎����r�i���j
[State -1, 1]
type       = Varset
trigger1   = Command = "16_b"
v          = 0
value      = 1210

;---------------------------------------------------------------------------
; �򉍎����r�i��j
[State -1, 1]
type       = Varset
trigger1   = Command = "16_c"
v          = 0
value      = 1220

;---------------------------------------------------------------------------
; �b�󌝁i���j
[State -1, 1]
type       = Varset
trigger1   = Command = "646_x"
v          = 0
value      = 1300

;---------------------------------------------------------------------------
; �b�󌝁i���j
[State -1, 1]
type       = Varset
trigger1   = Command = "646_y"
v          = 0
value      = 1310

;---------------------------------------------------------------------------
; �b�󌝁i��j
[State -1, 1]
type       = Varset
trigger1   = Command = "646_z"
v          = 0
value      = 1320

;---------------------------------------------------------------------------
; �e���ęጝ�i���j
[State -1, 1]
type       = Varset
trigger1   = Command = "641236_x"
v          = 0
value      = 1400

;---------------------------------------------------------------------------
; �e���ęጝ�i���j
[State -1, 1]
type       = Varset
trigger1   = Command = "641236_y"
v          = 0
value      = 1410

;---------------------------------------------------------------------------
; �e���ęጝ�i��j
[State -1, 1]
type       = Varset
trigger1   = Command = "641236_z"
v          = 0
value      = 1420

;---------------------------------------------------------------------------
; ���`�E�e���ęጝ�i���j
[State -1, 1]
type       = Varset
trigger1   = Command = "641236_a"
trigger1   = Life  <= 300  ||  power >= 1000
v          = 0
value      = 3000

;---------------------------------------------------------------------------
; ���`�E�e���ęጝ�i���j
[State -1, 1]
type       = Varset
trigger1   = Command = "641236_b"
trigger1   = Life  <= 300  ||  power >= 1000
v          = 0
value      = 3010

;---------------------------------------------------------------------------
; ���`�E�e���ęጝ�i��j
[State -1, 1]
type       = Varset
trigger1   = Command = "641236_c"
trigger1   = Life  <= 300  ||  power >= 1000
v          = 0
value      = 3020

;---------------------------------------------------------------------------
; ���՗���
[State -1, 1]
type       = Varset
triggerAll  = Command = "ranbu_p"
trigger1   = Life  <= 200  ||  power >= 3000
v          = 0
value      = 3100

;---------------------------------------------------------------------------
; �V�n�e����
[State -1, 1]
type       = Varset
trigger1   = Command = "ranbu_k"
trigger1   = Life  <= 300  ||  power >= 1000
v          = 0
value      = 3200

;---------------------------------------------------------------------------
; ���Ս���
[State -1, 1]
type       = Varset
trigger1   = Command = "ranbu_pk"
trigger1   = NumHelper(3300) = 0
;trigger1   = Life  <= 300  ||  power >= 1000
v          = 0
value      = 3300


;===========================================================================
;�K�E�Z�����i�n��Z�j
[State -1, 0]
type = ChangeState
value = Var(0)
triggerall = Var(0) > 999
trigger1   = statetype = S || statetype = C
trigger1   = ctrl
trigger2  = stateno = 20   ; �O�i��
trigger3  = stateno = 21   ; ��ޒ�
trigger4  = stateno = 200  ; �ߗ����o
trigger4  = movecontact
trigger5  = stateno = 201  ; �������o
trigger5  = movecontact
trigger6  = stateno = 230  ; �ߗ����j
trigger6  = movecontact
trigger7  = stateno = 231  ; �������j
trigger7  = movecontact
trigger8  = stateno = 210  ; �ߗ����o
trigger8  = movecontact
trigger9  = stateno = 211  ; �������o
trigger9  = movecontact
trigger10 = stateno = 240  ; �ߗ����j
trigger10 = movecontact
trigger11 = stateno = 241  ; �������j
trigger11 = movecontact
trigger12 = stateno = 220  ; �ߗ���o
trigger12 = movecontact
trigger13 = stateno = 221  ; ������o
trigger13 = movecontact
trigger14 = stateno = 250  ; �ߗ���j
trigger14 = movecontact
trigger15 = stateno = 251  ; ������j
trigger15 = movecontact
trigger16 = stateno = 400  ; �����o
trigger16 = movecontact
trigger17 = stateno = 430  ; �����j
trigger17 = movecontact
trigger18 = stateno = 410  ; �����o
trigger18 = movecontact
trigger19 = stateno = 440  ; �����j
trigger19 = movecontact
trigger20 = stateno = 300  ; ������΂��U��
trigger20 = movecontact
trigger21 = stateno = 310  ; �����U��
trigger21 = movecontact
trigger22 = Var(0) = 3100
trigger22 = stateno = 1212 ; ���򉍎����r�Q�i��
trigger22 = movecontact
trigger23 = Var(0) = 3100
trigger23 = stateno = 3200 ; �V�n�e����
trigger23 = movecontact
trigger23 = Life  <= 200  ||  power >= 3000
trigger24 = Var(0) = 3100
trigger24 = stateno = 3300 ; ���Ս���J�n
trigger24 = Life  <= 200  ||  power >= 3000
trigger24 = Time > 80


;�K�E�Z�����i�󒆋Z�j
[State -1, 0]
type = ChangeState
value = Var(0) + 700 + Var(6)
triggerall = Var(0) > 999
triggerall = Var(0) = [1000,1020]
triggerall = statetype = A
trigger1   = statetype = A
trigger1   = ctrl
trigger2   = stateno = 600 ; 
trigger2   = movecontact
trigger3   = stateno = 610 ; 
trigger3   = movecontact
trigger4   = stateno = 620 ; 
trigger4   = movecontact
trigger5   = stateno = 630 ; 
trigger5   = movecontact
trigger6   = stateno = 640 ; 
trigger6   = movecontact
trigger7   = stateno = 650 ; 
trigger7   = movecontact

;===========================================================================
;Reversal �K�E�Z�����i�n��Z�j
[State -1, 0]
type = ChangeState
value = Var(0)
triggerall = Var(0) > 999
trigger1   = statetype = S || statetype = C
trigger1   = stateno = 5001               ; ��炢��
trigger1   = HitOver
trigger2   = statetype = S || statetype = C
trigger2   = stateno = 5011               ; ����炢��
trigger2   = HitOver
trigger3   = stateno = 5120               ; �N��������
trigger3   = AnimTime = 0

;Reversal �K�E�Z�����i�󒆋Z�j
[State -1, 0]
type = ChangeState
value = Var(0) + 700 + Var(6)
triggerall = Var(0) > 999
triggerall = Var(0) = [1000,1020]
triggerall = statetype = A
trigger1   = stateno = 5001               ; ��炢��
trigger1   = HitOver
trigger2   = stateno = 5011               ; ����炢��
trigger2   = HitOver

;===========================================================================
;�󒆌���������p Var(6)
[State -1,Var_6]
type                = Varset
trigger1   = Var(2) = 18
v                   = 6
value               = 0

;��s���͉���
[State -1, 1]
type       = Varset
trigger1   = Var(2) = 18
v          = 0
value      = 0

;��s���͉����p
[State -1, 1]
type       = Varset
trigger1   = Var(2) = 18
v          = 2
value      = 0

;===========================================================================
;===========================================================================
;---------------------------------------------------------------------------
; �O�_�b�V�� RunFwd
[State -1]
type = ChangeState
value = 100
trigger1 = command = "FF"
trigger1 = statetype = S
trigger1 = ctrl = 1

;---------------------------------------------------------------------------
; �o�b�N�X�e�b�v RunBack
[State -1]
type = ChangeState
value = 105
trigger1 = command = "BB"
trigger1 = statetype = S
trigger1 = ctrl = 1

;---------------------------------------------------------------------------
; �ʏ퓊�� Stand_Throw (close dir+b)
[State -1]
type = ChangeState
value = 1500
triggerall = statetype = S
triggerall = ctrl = 1
triggerall = p2bodydist X < 32 ;Near P2
trigger1 = command = "fwd_y"
trigger2 = command = "fwd_z"
trigger3 = command = "back_y"
trigger4 = command = "back_z"
trigger5 = command = "fwd_b"
trigger6 = command = "fwd_c"
trigger7 = command = "back_b"
trigger8 = command = "back_c"

;---------------------------------------------------------------------------
; �󒆓��� (close dir+b)
;[State -1]
;type = ChangeState
;value = 1600
;triggerall = statetype = A
;triggerall = ctrl = 1
;;triggerall = p2bodydist X <  160
;;triggerall = p2bodydist Y > -180
;;triggerall = p2bodydist Y < 80
;triggerall = p2statetype != C
;triggerall = p2statetype != L
;triggerall = p2statetype != S
;triggerall = p2movetype != H
;trigger1 = command = "fwd_y"
;trigger2 = command = "fwd_z"
;trigger3 = command = "back_y"
;trigger4 = command = "back_z"
;trigger5 = command = "fwd_b"
;trigger6 = command = "fwd_c"
;trigger7 = command = "back_b"
;trigger8 = command = "back_c"
;trigger9 = command = "down_b"
;trigger10 = command = "down_c"
;trigger11 = command = "down_y"
;trigger12 = command = "down_z"



;===========================================================================
;---------------------------------------------------------------------------
; ������΂��U��(��O)
[State -1]
type = ChangeState
value = 300
triggerall = command = "cz"
trigger1 = statetype = S
trigger1 = ctrl = 1
trigger2  = stateno = 20   ; �O�i��
trigger3  = stateno = 21   ; ��ޒ�
trigger4  = stateno = 200  ; �ߗ����o
trigger4  = movecontact = 1
trigger5  = stateno = 201  ; �������o
trigger5  = movecontact = 1
trigger6  = stateno = 230  ; �ߗ����j
trigger6  = movecontact = 1
trigger7  = stateno = 231  ; �������j
trigger7  = movecontact = 1
trigger8  = stateno = 210  ; �ߗ����o
trigger8  = movecontact = 1
trigger9  = stateno = 211  ; �������o
trigger9  = movecontact = 1
trigger10 = stateno = 240  ; �ߗ����j
trigger10 = movecontact = 1
trigger11 = stateno = 241  ; �������j
trigger11 = movecontact = 1
trigger12 = stateno = 220  ; �ߗ���o
trigger12 = movecontact = 1
trigger13 = stateno = 221  ; ������o
trigger13 = movecontact = 1
trigger14 = stateno = 250  ; �ߗ���j
trigger14 = movecontact = 1
trigger15 = stateno = 251  ; ������j
trigger15 = movecontact = 1
trigger16 = stateno = 400  ; �����o
trigger16 = movecontact = 1
trigger17 = stateno = 430  ; �����j
trigger17 = movecontact = 1
trigger18 = stateno = 410  ; �����o
trigger18 = movecontact = 1
trigger19 = stateno = 440  ; �����j
trigger19 = movecontact = 1

;---------------------------------------------------------------------------
; �����U��
[State -1]
type = ChangeState
value = 310
triggerall  = (stateno = 130) ||  (stateno = 140) ||  (stateno = 150)
triggerall  = statetype = S
trigger1 = command = "6_x"
trigger2 = command = "6_a"

;trigger1 = statetype = S
;trigger1 = ctrl = 1
;trigger1 = command = "ax"

;triggerall = statetype = S
;triggerall = ctrl = 1
;trigger1 = command = "6_x"
;trigger1 = StateNo = 130
;trigger2 = command = "6_a"
;trigger2 = StateNo = 130
;trigger3 = command = "6_x"
;trigger3 = StateNo = 131
;trigger4 = command = "6_a"
;trigger4 = StateNo = 131
;trigger5 = command = "6_x"
;trigger5 = StateNo = 140
;trigger6 = command = "6_a"
;trigger6 = StateNo = 140
;trigger7 = command = "6_x"
;trigger7 = StateNo = 141
;trigger8 = command = "6_a"
;trigger8 = StateNo = 141
;trigger9 = command = "6_x"
;trigger9 = StateNo = 120
;trigger10 = command = "6_a"
;trigger10 = StateNo = 120
;trigger11 = command = "6_x"
;trigger11 = StateNo = 121
;trigger12 = command = "6_a"
;trigger12 = StateNo = 121

;---------------------------------------------------------------------------
; ������΂��U��(��)
[State -1]
type = ChangeState
value = 320
triggerall = command = "by"
trigger1 = statetype = S
trigger1 = ctrl = 1
trigger2  = stateno = 20   ; �O�i��
trigger3  = stateno = 21   ; ��ޒ�
trigger4  = stateno = 200  ; �ߗ����o
trigger4  = movecontact = 1
trigger5  = stateno = 201  ; �������o
trigger5  = movecontact = 1
trigger6  = stateno = 230  ; �ߗ����j
trigger6  = movecontact = 1
trigger7  = stateno = 231  ; �������j
trigger7  = movecontact = 1
trigger8  = stateno = 210  ; �ߗ����o
trigger8  = movecontact = 1
trigger9  = stateno = 211  ; �������o
trigger9  = movecontact = 1
trigger10 = stateno = 240  ; �ߗ����j
trigger10 = movecontact = 1
trigger11 = stateno = 241  ; �������j
trigger11 = movecontact = 1
trigger12 = stateno = 220  ; �ߗ���o
trigger12 = movecontact = 1
trigger13 = stateno = 221  ; ������o
trigger13 = movecontact = 1
trigger14 = stateno = 250  ; �ߗ���j
trigger14 = movecontact = 1
trigger15 = stateno = 251  ; ������j
trigger15 = movecontact = 1
trigger16 = stateno = 400  ; �����o
trigger16 = movecontact = 1
trigger17 = stateno = 430  ; �����j
trigger17 = movecontact = 1
trigger18 = stateno = 410  ; �����o
trigger18 = movecontact = 1
trigger19 = stateno = 440  ; �����j
trigger19 = movecontact = 1

;---------------------------------------------------------------------------
; �������p���`�i�߁j Stand_A
[State -1]
type = ChangeState
value = 200
triggerall = command = "x";Place name of command here
triggerall = command != "holddown";Standing moves should have this line
triggerall = P2BodyDist X < 32
 ;The following is true if Player is in stand state, and has control
trigger1 = statetype = S
trigger1 = ctrl = 1
trigger2 = stateno = 20   ; �O�i��
trigger3 = stateno = 21   ; ��ޒ�
 ;Uncomment the following if you want to be able to do a Stand_A rapidly
trigger2 = stateno = 200  ; �ߗ����o
trigger2 = time >= 7

;---------------------------------------------------------------------------
; �������p���`�i���j Stand_A
[State -1]
type = ChangeState
value = 201
triggerall = command = "x";Place name of command here
triggerall = command != "holddown";Standing moves should have this line
 ;The following is true if Player is in stand state, and has control
trigger1 = statetype = S
trigger1 = ctrl = 1
trigger2 = stateno = 20   ; �O�i��
trigger3 = stateno = 21   ; ��ޒ�
 ;Uncomment the following if you want to be able to do a Stand_A rapidly
trigger4 = stateno = 200  ; �ߗ����o
trigger4 = time >= 7

;---------------------------------------------------------------------------
; �������p���`�i�߁j Stand_B
[State -1]
type = ChangeState
value = 210
triggerall = command = "y"
triggerall = command != "holddown"
triggerall = P2BodyDist X < 32
trigger1 = statetype = S
trigger1 = ctrl = 1
 ;Uncomment the following if you want to be able to "chain" the attack
trigger2  = stateno = 20   ; �O�i��
trigger3  = stateno = 21   ; ��ޒ�
trigger4  = stateno = 200  ; �ߗ����o
trigger4  = movecontact = 1
trigger5  = stateno = 201  ; �������o
trigger5  = movecontact = 1
trigger6  = stateno = 230  ; �ߗ����j
trigger6  = movecontact = 1
trigger7  = stateno = 231  ; �������j
trigger7  = movecontact = 1
trigger8  = stateno = 400  ; �����o
trigger8  = movecontact = 1
trigger9  = stateno = 430  ; �����j
trigger9  = movecontact = 1

;---------------------------------------------------------------------------
; �������p���`�i���j Stand_B
[State -1]
type = ChangeState
value = 211
triggerall = command = "y"
triggerall = command != "holddown"
trigger1 = statetype = S
trigger1 = ctrl = 1
 ;Uncomment the following if you want to be able to "chain" the attack
 ;from a Stand_A (state 200)
trigger2  = stateno = 20   ; �O�i��
trigger3  = stateno = 21   ; ��ޒ�
trigger4  = stateno = 200  ; �ߗ����o
trigger4  = movecontact = 1
trigger5  = stateno = 201  ; �������o
trigger5  = movecontact = 1
trigger6  = stateno = 230  ; �ߗ����j
trigger6  = movecontact = 1
trigger7  = stateno = 231  ; �������j
trigger7  = movecontact = 1
trigger8  = stateno = 210  ; �ߗ����o
trigger8  = movecontact = 1
trigger9  = stateno = 400  ; �����o
trigger9  = movecontact = 1
trigger10 = stateno = 430  ; �����j
trigger10 = movecontact = 1

;---------------------------------------------------------------------------
; ������p���`�i�߁j
[State -1]
type = ChangeState
value = 220
triggerall = command = "z";Place name of command here
triggerall = command != "holddown";Standing moves should have this line
triggerall = P2BodyDist X < 32
 ;The following is true if Player is in stand state, and has control
trigger1 = statetype = S
trigger1 = ctrl = 1
 ;Uncomment the following if you want to be able to do a Stand_A rapidly
trigger2  = stateno = 20   ; �O�i��
trigger3  = stateno = 21   ; ��ޒ�
trigger4  = stateno = 200  ; �ߗ����o
trigger4  = movecontact = 1
trigger5  = stateno = 201  ; �������o
trigger5  = movecontact = 1
trigger6  = stateno = 230  ; �ߗ����j
trigger6  = movecontact = 1
trigger7  = stateno = 231  ; �������j
trigger7  = movecontact = 1
trigger8  = stateno = 210  ; �ߗ����o
trigger8  = movecontact = 1
trigger9  = stateno = 211  ; �������o
trigger9  = movecontact = 1
trigger10 = stateno = 240  ; �ߗ����j
trigger10 = movecontact = 1
trigger11 = stateno = 241  ; �������j
trigger11 = movecontact = 1
trigger12 = stateno = 400  ; �����o
trigger12 = movecontact = 1
trigger13 = stateno = 430  ; �����j
trigger13 = movecontact = 1
trigger14 = stateno = 410  ; �����o
trigger14 = movecontact = 1
trigger15 = stateno = 440  ; �����j
trigger15 = movecontact = 1

;---------------------------------------------------------------------------
; ������p���`�i���j Stand_C
[State -1]
type = ChangeState
value = 221
triggerall = command = "z";Place name of command here
triggerall = command != "holddown";Standing moves should have this line
 ;The following is true if Player is in stand state, and has control
trigger1 = statetype = S
trigger1 = ctrl = 1
 ;Uncomment the following if you want to be able to do a Stand_A rapidly
trigger2  = stateno = 20   ; �O�i��
trigger3  = stateno = 21   ; ��ޒ�
trigger4  = stateno = 200  ; �ߗ����o
trigger4  = movecontact = 1
trigger5  = stateno = 201  ; �������o
trigger5  = movecontact = 1
trigger6  = stateno = 230  ; �ߗ����j
trigger6  = movecontact = 1
trigger7  = stateno = 231  ; �������j
trigger7  = movecontact = 1
trigger8  = stateno = 210  ; �ߗ����o
trigger8  = movecontact = 1
trigger9  = stateno = 211  ; �������o
trigger9  = movecontact = 1
trigger10 = stateno = 240  ; �ߗ����j
trigger10 = movecontact = 1
trigger11 = stateno = 241  ; �������j
trigger11 = movecontact = 1
trigger12 = stateno = 210  ; �ߗ���o
trigger12 = movecontact = 1
trigger13 = stateno = 400  ; �����o
trigger13 = movecontact = 1
trigger14 = stateno = 430  ; �����j
trigger14 = movecontact = 1
trigger15 = stateno = 410  ; �����o
trigger15 = movecontact = 1
trigger16 = stateno = 440  ; �����j
trigger16 = movecontact = 1

;---------------------------------------------------------------------------
; �������L�b�N �i�߁j
[State -1]
type = ChangeState
value = 230
triggerall = command = "a";Place name of command here
triggerall = command != "holddown";Standing moves should have this line
triggerall = P2BodyDist X < 32
 ;The following is true if Player is in stand state, and has control
trigger1 = statetype = S
trigger1 = ctrl = 1
 ;Uncomment the following if you want to be able to do a Stand_A rapidly
trigger2  = stateno = 20   ; �O�i��
trigger3  = stateno = 21   ; ��ޒ�
trigger4  = stateno = 200  ; �ߗ����o
trigger4  = movecontact = 1
trigger5  = stateno = 201  ; �������o
trigger5  = movecontact = 1
trigger6  = stateno = 400  ; �����o
trigger6  = movecontact = 1

;---------------------------------------------------------------------------
; �������L�b�N �i���j
[State -1]
type = ChangeState
value = 231
triggerall = command = "a";Place name of command here
triggerall = command != "holddown";Standing moves should have this line
 ;The following is true if Player is in stand state, and has control
trigger1 = statetype = S
trigger1 = ctrl = 1
 ;Uncomment the following if you want to be able to do a Stand_A rapidly
trigger2  = stateno = 20   ; �O�i��
trigger3  = stateno = 21   ; ��ޒ�
trigger4  = stateno = 200  ; �ߗ����o
trigger4  = movecontact = 1
trigger5  = stateno = 201  ; �������o
trigger5  = movecontact = 1
trigger6  = stateno = 230  ; �ߗ����j
trigger6  = movecontact = 1
trigger7  = stateno = 400  ; �����o
trigger7  = movecontact = 1

;---------------------------------------------------------------------------
; �������L�b�N�i�߁j
[State -1]
type = ChangeState
value = 240
triggerall = command = "b"
triggerall = command != "holddown"
trigger1 = statetype = S
trigger1 = ctrl = 1
triggerall = P2BodyDist X < 32
 ;Uncomment the following if you want to be able to "chain" the attack
 ;from a Stand_A (state 200)
trigger2  = stateno = 20   ; �O�i��
trigger3  = stateno = 21   ; ��ޒ�
trigger4  = stateno = 200  ; �ߗ����o
trigger4  = movecontact = 1
trigger5  = stateno = 201  ; �������o
trigger5  = movecontact = 1
trigger6  = stateno = 230  ; �ߗ����j
trigger6  = movecontact = 1
trigger7  = stateno = 231  ; �������j
trigger7  = movecontact = 1
trigger8  = stateno = 210  ; �ߗ����o
trigger8  = movecontact = 1
trigger9  = stateno = 211  ; �������o
trigger9  = movecontact = 1
trigger10 = stateno = 400  ; �����o
trigger10 = movecontact = 1
trigger11 = stateno = 430  ; �����j
trigger11 = movecontact = 1
trigger12 = stateno = 410  ; �����o
trigger12 = movecontact = 1

;---------------------------------------------------------------------------
; �������L�b�N�i���j
[State -1]
type = ChangeState
value = 241
triggerall = command = "b"
triggerall = command != "holddown"
trigger1 = statetype = S
trigger1 = ctrl = 1
 ;Uncomment the following if you want to be able to "chain" the attack
 ;from a Stand_A (state 200)
trigger2  = stateno = 20   ; �O�i��
trigger3  = stateno = 21   ; ��ޒ�
trigger4  = stateno = 200  ; �ߗ����o
trigger4  = movecontact = 1
trigger5  = stateno = 201  ; �������o
trigger5  = movecontact = 1
trigger6  = stateno = 230  ; �ߗ����j
trigger6  = movecontact = 1
trigger7  = stateno = 231  ; �������j
trigger7  = movecontact = 1
trigger8  = stateno = 210  ; �ߗ����o
trigger8  = movecontact = 1
trigger9  = stateno = 211  ; �������o
trigger9  = movecontact = 1
trigger10 = stateno = 240  ; �ߗ����j
trigger10 = movecontact = 1
trigger11 = stateno = 400  ; �����o
trigger11 = movecontact = 1
trigger12 = stateno = 430  ; �����j
trigger12 = movecontact = 1
trigger13 = stateno = 410  ; �����o
trigger13 = movecontact = 1

;---------------------------------------------------------------------------
; ������L�b�N�i�߁j
[State -1]
type = ChangeState
value = 250
triggerall = command = "c";Place name of command here
triggerall = command != "holddown";Standing moves should have this line
triggerall = P2BodyDist X < 32
 ;The following is true if Player is in stand state, and has control
trigger1 = statetype = S
trigger1 = ctrl = 1
 ;Uncomment the following if you want to be able to do a Stand_A rapidly
trigger2  = stateno = 20   ; �O�i��
trigger3  = stateno = 21   ; ��ޒ�
trigger4  = stateno = 200  ; �ߗ����o
trigger4  = movecontact = 1
trigger5  = stateno = 201  ; �������o
trigger5  = movecontact = 1
trigger6  = stateno = 230  ; �ߗ����j
trigger6  = movecontact = 1
trigger7  = stateno = 231  ; �������j
trigger7  = movecontact = 1
trigger8  = stateno = 210  ; �ߗ����o
trigger8  = movecontact = 1
trigger9  = stateno = 211  ; �������o
trigger9  = movecontact = 1
trigger10 = stateno = 240  ; �ߗ����j
trigger10 = movecontact = 1
trigger11 = stateno = 241  ; �������j
trigger11 = movecontact = 1
trigger12 = stateno = 210  ; �ߗ���o
trigger12 = movecontact = 1
trigger13 = stateno = 211  ; ������o
trigger13 = movecontact = 1
trigger14 = stateno = 400  ; �����o
trigger14 = movecontact = 1
trigger15 = stateno = 430  ; �����j
trigger15 = movecontact = 1
trigger16 = stateno = 410  ; �����o
trigger16 = movecontact = 1
trigger17 = stateno = 440  ; �����j
trigger17 = movecontact = 1

;---------------------------------------------------------------------------
; ������L�b�N�i���j
[State -1]
type = ChangeState
value = 251
triggerall = command = "c";Place name of command here
triggerall = command != "holddown";Standing moves should have this line
 ;The following is true if Player is in stand state, and has control
trigger1 = statetype = S
trigger1 = ctrl = 1
 ;Uncomment the following if you want to be able to do a Stand_A rapidly
trigger2  = stateno = 20   ; �O�i��
trigger3  = stateno = 21   ; ��ޒ�
trigger4  = stateno = 200  ; �ߗ����o
trigger4  = movecontact = 1
trigger5  = stateno = 201  ; �������o
trigger5  = movecontact = 1
trigger6  = stateno = 230  ; �ߗ����j
trigger6  = movecontact = 1
trigger7  = stateno = 231  ; �������j
trigger7  = movecontact = 1
trigger8  = stateno = 210  ; �ߗ����o
trigger8  = movecontact = 1
trigger9  = stateno = 211  ; �������o
trigger9  = movecontact = 1
trigger10 = stateno = 240  ; �ߗ����j
trigger10 = movecontact = 1
trigger11 = stateno = 241  ; �������j
trigger11 = movecontact = 1
trigger12 = stateno = 210  ; �ߗ���o
trigger12 = movecontact = 1
trigger13 = stateno = 211  ; ������o
trigger13 = movecontact = 1
trigger14 = stateno = 400  ; �����o
trigger14 = movecontact = 1
trigger15 = stateno = 430  ; �����j
trigger15 = movecontact = 1
trigger16 = stateno = 410  ; �����o
trigger16 = movecontact = 1
trigger17 = stateno = 440  ; �����j
trigger17 = movecontact = 1

;---------------------------------------------------------------------------
; ���ݏ��p���` Crouch_A
[State -1]
type = ChangeState
value = 400
triggerall = command = "x"
triggerall = command = "holddown"
trigger1 = statetype = C
trigger1 = ctrl = 1
trigger2 = stateno = 110

;---------------------------------------------------------------------------
; ���ݒ��p���` Crouch_B
[State -1]
type = ChangeState
value = 410
triggerall = command = "y"
triggerall = command = "holddown"
trigger1 = statetype = C
trigger1 = ctrl = 1
trigger2 = stateno = 110
trigger3 = stateno = 400
trigger3 = movecontact = 1
trigger4 = stateno = 430
trigger4 = movecontact = 1
trigger5 = stateno = 200
trigger5 = movecontact = 1
trigger6 = stateno = 210
trigger6 = movecontact = 1
trigger7 = stateno = 230
trigger7 = movecontact = 1

;---------------------------------------------------------------------------
; ���ݑ�p���` Crouch_C
[State -1]
type = ChangeState
value = 420
triggerall = command = "z"
triggerall = command = "holddown"
trigger1 = statetype = C
trigger1 = ctrl = 1
trigger2 = stateno = 240
trigger2 = time >= 7
trigger3 = stateno = 110
trigger4 = stateno = 211
trigger4 = movecontact = 1  ;If move hits, or is guarded by opponent
trigger5 = stateno = 220
trigger5 = movecontact = 1  ;If move hits, or is guarded by opponent
trigger6 = stateno = 400
trigger6 = movecontact = 1
trigger7 = stateno = 430
trigger7 = movecontact = 1
trigger8 = stateno = 410
trigger8 = movecontact = 1
trigger9 = stateno = 440
trigger9 = movecontact = 1
trigger5 = stateno = 200
trigger5 = movecontact = 1
trigger6 = stateno = 210
trigger6 = movecontact = 1
trigger7 = stateno = 230
trigger7 = movecontact = 1

;---------------------------------------------------------------------------
; ���ݏ��L�b�N Crouch_X
[State -1]
type = ChangeState
value = 430
triggerall = command = "a"
triggerall = command = "holddown"
trigger1 = statetype = C
trigger1 = ctrl = 1
trigger2  = stateno = 30   ; ���O�i��
trigger3  = stateno = 200  ; �ߗ����o
trigger3  = movecontact = 1
trigger4  = stateno = 201  ; �������o
trigger4  = movecontact = 1
trigger5  = stateno = 400  ; �����o
trigger5  = movecontact = 1

;---------------------------------------------------------------------------
; ���ݒ��L�b�N Crouch_Y
[State -1]
type = ChangeState
value = 440
triggerall = command = "b"
triggerall = command = "holddown"
trigger1 = statetype = C
trigger1 = ctrl = 1
trigger2  = stateno = 30   ; ���O�i��
trigger3  = stateno = 200  ; �ߗ����o
trigger3  = movecontact = 1
trigger4  = stateno = 201  ; �������o
trigger4  = movecontact = 1
trigger5  = stateno = 230  ; �ߗ����j
trigger5  = movecontact = 1
trigger6  = stateno = 231  ; �������j
trigger6  = movecontact = 1
trigger7  = stateno = 210  ; �ߗ����o
trigger7  = movecontact = 1
trigger8  = stateno = 211  ; �������o
trigger8  = movecontact = 1
trigger9  = stateno = 400  ; �����o
trigger9  = movecontact = 1
trigger10 = stateno = 430  ; �����j
trigger10 = movecontact = 1
trigger11 = stateno = 410  ; �����o
trigger11 = movecontact = 1

;---------------------------------------------------------------------------
; ���ݑ�L�b�N Crouch_Z
[State -1]
type = ChangeState
value = 450
triggerall = command = "c"
triggerall = command = "holddown"
trigger1 = statetype = C
trigger1 = ctrl = 1
trigger2  = stateno = 30   ; ���O�i��
trigger3  = stateno = 200  ; �ߗ����o
trigger3  = movecontact = 1
trigger4  = stateno = 201  ; �������o
trigger4  = movecontact = 1
trigger5  = stateno = 230  ; �ߗ����j
trigger5  = movecontact = 1
trigger6  = stateno = 231  ; �������j
trigger6  = movecontact = 1
trigger7  = stateno = 210  ; �ߗ����o
trigger7  = movecontact = 1
trigger8  = stateno = 211  ; �������o
trigger8  = movecontact = 1
trigger9  = stateno = 240  ; �ߗ����j
trigger9  = movecontact = 1
trigger10 = stateno = 241  ; �������j
trigger10 = movecontact = 1
trigger11 = stateno = 220  ; �ߗ���o
trigger11 = movecontact = 1
trigger12 = stateno = 221  ; ������o
trigger12 = movecontact = 1
trigger13 = stateno = 400  ; �����o
trigger13 = movecontact = 1
trigger14 = stateno = 430  ; �����j
trigger14 = movecontact = 1
trigger15 = stateno = 410  ; �����o
trigger15 = movecontact = 1
trigger16 = stateno = 440  ; �����j
trigger16 = movecontact = 1

;---------------------------------------------------------------------------
; �W�����v���p���` Jump_A
[State -1]
type = ChangeState
value = 600
trigger1 = command = "x"
trigger1 = statetype = A
trigger1 = ctrl = 1
trigger1 = Pos Y < -50 

;---------------------------------------------------------------------------
; �W�����v���p���` Jump_B
[State -1]
type = ChangeState
value = 610
triggerall = command = "y"
triggerall = statetype = A
trigger1 = ctrl = 1
trigger1 = Pos Y < -50 
trigger2 = stateno = 600  ; �W�����v���o
trigger2 = movecontact = 1
trigger3 = stateno = 630  ; �W�����v���j
trigger3 = movecontact = 1

;---------------------------------------------------------------------------
; �W�����v��p���` Jump_C
[State -1]
type = ChangeState
value = 620
triggerall = command = "z"
triggerall = statetype = A
trigger1 = ctrl = 1
trigger1 = Pos Y < -50 
trigger2 = stateno = 600  ; �W�����v���o
trigger2 = movecontact = 1
trigger3 = stateno = 610  ; �W�����v���o
trigger3 = movecontact = 1
trigger4 = stateno = 630  ; �W�����v���j
trigger4 = movecontact = 1
trigger5 = stateno = 640  ; �W�����v���j
trigger5 = movecontact = 1

;---------------------------------------------------------------------------
; �W�����v���L�b�N Jump_X
[State -1]
type = ChangeState
value = 630
triggerall = command = "a"
triggerall = statetype = A
trigger1 = ctrl = 1
trigger1 = Pos Y < -50 
trigger2 = stateno = 600  ; �W�����v���o
trigger2 = movecontact = 1

;---------------------------------------------------------------------------
; �W�����v���L�b�N Jump_Y
[State -1]
type = ChangeState
value = 640
triggerall = command = "b"
triggerall = statetype = A
trigger1 = ctrl = 1
trigger1 = Pos Y < -50 
trigger2 = stateno = 600  ; �W�����v���o
trigger2 = movecontact = 1
trigger3 = stateno = 610  ; �W�����v���o
trigger3 = movecontact = 1
trigger4 = stateno = 630  ; �W�����v���j
trigger4 = movecontact = 1

;---------------------------------------------------------------------------
; �W�����v��L�b�N Jump_Z
[State -1]
type = ChangeState
value = 650
triggerall = command = "c"
triggerall = statetype = A
trigger1 = ctrl = 1
trigger1 = Pos Y < -50 
trigger2 = stateno = 600  ; �W�����v���o
trigger2 = movecontact = 1
trigger3 = stateno = 610  ; �W�����v���o
trigger3 = movecontact = 1
trigger4 = stateno = 620  ; �W�����v��o
trigger4 = movecontact = 1
trigger5 = stateno = 630  ; �W�����v���j
trigger5 = movecontact = 1
trigger6 = stateno = 640  ; �W�����v���j
trigger6 = movecontact = 1

;---------------------------------------------------------------------------
; ����
[State -1]
type = ChangeState
value = 195
trigger1 = command = "s"
trigger1 = statetype = S
trigger1 = ctrl = 1

;---------------------------------------------------------------------------
; ���ݑO�i
[State -1]
type = ChangeState
value = 30
trigger1 = command = "holdfwddown"
trigger1 = statetype = C
trigger1 = ctrl = 1

;---------------------------------------------------------------------------
; �����K�[�h�i�������j
[State -1]
type = ChangeState
value = 120
trigger1  = StateType = S
trigger1  = ctrl 
trigger1  = Command = "holdback"
trigger1  = enemy,movetype = A

;---------------------------------------------------------------------------
; �C�͗���
[State -1]
type = ChangeState
value = 900
triggerall = p2bodydist x > 100
triggerall = AnimTime = [0, 2]
triggerall = (Command = "hold_a") || (Command = "hold_b") || (Command = "hold_c") || (Command = "hold_x") || (Command = "hold_y") || (Command = "hold_z")
trigger1  = (stateno = [200,251])
trigger2  = (stateno = [300,310])
trigger3  = (stateno = [1000,1020])
trigger4  = (stateno = 1104)
trigger5  = (stateno = 1204)
trigger6  = (stateno = 1302)
trigger7  = (stateno = 1303)
trigger8  = (stateno = 1313)
trigger9  = (stateno = 1323)
trigger10 = (stateno = 1400)
trigger11 = (stateno = 1410)
trigger12 = (stateno = 1420)

